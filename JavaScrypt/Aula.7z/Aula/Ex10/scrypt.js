let Velocidade = prompt("Digite a velocidade da via")

let num = [5,8,2,9,3]

console.log(`Nosso vetor é o ${num}`)

let num = [5,8,4]
num[3] = 6


