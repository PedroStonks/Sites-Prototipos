function clicar(){
    a.innerText = 'Clicou!'
    a.style.background = 'red'
 }


 function Calcular(){
    else {
        
    }
    

 }